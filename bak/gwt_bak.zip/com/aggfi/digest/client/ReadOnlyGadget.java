package com.aggfi.digest.client;


import com.aggfi.digest.client.inject.GinjectorImpl;
import com.aggfi.digest.client.ui.MainPanel;
import com.allen_sauer.gwt.log.client.DivLogger;
import com.allen_sauer.gwt.log.client.Log;
import com.google.gwt.core.client.EntryPoint;
import com.google.gwt.core.client.GWT;
import com.google.gwt.gadgets.client.Gadget.AllowHtmlQuirksMode;
import com.google.gwt.gadgets.client.Gadget.ModulePrefs;
import com.google.gwt.gadgets.client.Gadget.UseLongManifestName;
import com.google.gwt.user.client.ui.AbsolutePanel;
import com.google.gwt.user.client.ui.RootPanel;
@AllowHtmlQuirksMode
@UseLongManifestName
@ModulePrefs(title = "New post Gadget",author="Yuri Zelikov",author_email="vega113+newpostgadget@gmail.com")
public class ReadOnlyGadget  implements EntryPoint {
	public void onModuleLoad() {
		GinjectorImpl ginjector = GWT.create(GinjectorImpl.class);
		MainPanel widget = ginjector.getMainPanel();
	    RootPanel.get("mainPanel").add(widget);
	    initRemoteLogger(RootPanel.get("logPanel"));
	}
	
	public void initRemoteLogger(AbsolutePanel panel){
		Log.setUncaughtExceptionHandler();
		if (panel != null) {
			panel.add (Log.getLogger(DivLogger.class).getWidget());
			Log.info("Logger initialized: " + Log.class.getName());
		}
	}
}
