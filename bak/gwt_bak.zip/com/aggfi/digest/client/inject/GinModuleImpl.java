

package com.aggfi.digest.client.inject;
import com.aggfi.digest.client.service.NewPostGadgetService;
import com.aggfi.digest.client.service.NewPostGadgetServiceImpl;
import com.google.gwt.inject.client.AbstractGinModule;
import com.google.inject.Singleton;
import com.vegalabs.general.client.request.GwtRequestServiceImpl;
import com.vegalabs.general.client.request.RequestService;
import com.vegalabs.general.client.utils.VegaUtils;
import com.vegalabs.general.client.utils.VegaUtilsImpl;

/**
 * This gin module binds an implementation for the
 * {@link com.google.gwt.inject.example.simple.client.SimpleService} used in
 * this example application. Note that we don't have to bind implementations
 * for {@link com.google.gwt.inject.DigestConstants.simple.client.SimpleConstants} and
 * {@link com.google.gwt.inject.DigestMessages.simple.client.SimpleMessages} - they
 * are constructed by Gin through GWT.create.
 */
public class GinModuleImpl extends AbstractGinModule {

	protected void configure() {

		bind(NewPostGadgetService.class).to(NewPostGadgetServiceImpl.class);
		bind(VegaUtils.class).to(VegaUtilsImpl.class);
		bind(RequestService.class).to(GwtRequestServiceImpl.class).in(Singleton.class);

	}
}
